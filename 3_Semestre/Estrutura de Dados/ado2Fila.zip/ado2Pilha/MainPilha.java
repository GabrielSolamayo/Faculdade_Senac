/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ado2Pilha;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 *
 * @author eric
 */
public class MainPilha {

    public static void main(String[] args) {
        Pilha p = new Pilha();
        p.push(new JogosDeVideoGame("God of War Ragnarok", "ação e aventura"));
        p.push(new JogosDeVideoGame("Fifa 2023", "Futebol"));
        p.push(new JogosDeVideoGame("Need for Speed", "Corrida"));
        p.push(new JogosDeVideoGame("Formula 1", "Corrida"));
        p.push(new JogosDeVideoGame("Forza Horizon", "Corrida"));
        p.push(new JogosDeVideoGame("Gta V", "Ação e Aventura"));
        p.push(new JogosDeVideoGame("Far Cry 5", "tiro"));
        p.push(new JogosDeVideoGame("Batman: Arkham City", "ação e aventura"));
        p.push(new JogosDeVideoGame("The Legend of Zelda", "ação e aventura"));
        p.push(new JogosDeVideoGame("Resident Evil 4", "ação e aventura"));
        p.push(new JogosDeVideoGame("Resident Evil 5", "ação e aventura"));
        p.exibirPilha();

        System.out.println("\nQuem está no topo da pilha ?");
        System.out.println("R: Topo = " + p.top());

        System.out.println("\n\t\tRemovendo da pilha os jogos\n");
        p.pop();
        p.pop();
        p.pop();
        p.pop();
        p.pop();
        p.pop();

        System.out.println("\nQuem está no topo da pilha ?");
        System.out.println("R: Topo = " + p.top());

        p.exibirPilha();
        System.out.println();

        System.out.println("\nA pilha está cheia ?");
        if (p.empty() == true) {
            System.out.println("R: Sim, a pilha esta cheia. ");
        } else {
            System.out.println("R: Não, A pilha está vazia.");
        }

        System.out.println("\nQual é o tamanho da pilha ?");
        System.out.println("R: O tamanho da pilha é " + p.size());

        System.out.println("\nQuem é o primeiro da pilha ?");
        System.out.println("R: O primeiro da pilha é " + p.top());

        System.out.println();
        p.exibirPilha();

    }
}
