/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ado2Fila;

/**
 *
 * @author eric
 */
public class Fila {

    public Fila() {
        new Lista();
    }

    public void enqueue(Object obj) {
        Lista.inserir(obj);
    }

    public void dequeue() {
        Lista.remover(this.front());
    }

    public Object front() {
        return Lista.getInicio().getObjeto();
    }

    public boolean empty() {

        if (this.size() != 0) {
            return true;
        }
        return false;
    }

    public int size() {
        Elemento e = Lista.getInicio();

        int contador = 0;
        while (e != null) {
            e = e.getProximo();
            contador++;
        }

        return contador;
    }

    public void exibirFila() {
        Lista.exibir();
    }

}
