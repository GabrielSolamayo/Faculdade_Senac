/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ado2Fila;

/**
 *
 * @author eric
 */
public class MainFila {

    public static void main(String[] args) {
        Fila fila = new Fila();

        fila.enqueue(new BancoSenac("Erick ", 23, "Abrir conta"));
        fila.enqueue(new BancoSenac("Djalma ", 20, "Abrir conta"));
        fila.enqueue(new BancoSenac("Marcos ", 27, "Reprovado"));
        fila.enqueue(new BancoSenac("Rodrigo ", 27, "Reprovado"));

        fila.enqueue(new BancoSenac("Cafu ", 27, "Passar de ano"));
        fila.enqueue(new BancoSenac("Francisco ", 27, "Graduação"));
        fila.enqueue(new BancoSenac("Alana ", 27, "Pós-Graduação"));
        fila.enqueue(new BancoSenac("Juliana ", 35, "Pós-Graduação"));

        System.out.println();
        fila.exibirFila();

        System.out.println("\nQuem está no topo da fila ?");
        System.out.println("R: Topo = " + fila.front());

        System.out.println("\n\t\tRemovendo da fila");
        fila.dequeue();
        fila.dequeue();
        fila.dequeue();
        fila.dequeue();
        fila.dequeue();
        fila.dequeue();

        System.out.println("\nQuem está no topo da fila ?");
        System.out.println("R: Topo = " + fila.front());

        System.out.println();
        fila.exibirFila();

        System.out.println("\nA fila está cheia ?");
        if (fila.empty() == true) {
            System.out.println("R: Sim, a fila esta cheia. ");
        } else {
            System.out.println("R: Não, A fila está vazia.");
        }

        System.out.println("\nQual é o tamanho da fila ?");
        System.out.println("R: O tamanho da fila é " + fila.size());

        System.out.println("\nQuem é o primeiro da fila ?");
        System.out.println("R: O primeiro da fila é " + fila.front());

        System.out.println();
        fila.exibirFila();

    }
}
