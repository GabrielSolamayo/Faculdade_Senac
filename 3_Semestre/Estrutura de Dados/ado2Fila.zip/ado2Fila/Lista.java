/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ado2Fila;

/**
 *
 * @author eric
 */
public class Lista {

    private static Elemento inicio, atual, aux;

    public static void inserir(Object obj) {

        if (obj instanceof BancoSenac) {

            if (inicio == null) {
                inicio = new Elemento(null, null, obj);
                aux = inicio;
            } else {
                atual = new Elemento(null, aux, obj);
                aux.setProximo(atual);
                aux = atual;
            }
        } else {
            System.out.println("Objeto inválido");
        }
    }

    public static void exibir() {
        System.out.println("\t\tFila do Banco Senac\n");
        Elemento e = inicio;
        while (e != null) {
            System.out.println(e.getObjeto());
            e = e.getProximo();
        }
        System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

    }

    public static Object remover(Object obj) {
        try {
            Elemento e = inicio;
            if (e != null) {
                if (e == inicio && inicio != null) {
                    System.out.println(e.objeto);
                    inicio = e.getProximo();
                    aux.setProximo(null);
                    inicio.setAnterior(null);
                }
            }
        } catch (NullPointerException e) {
            System.out.println("Erro na remoção, fila vazia!\n");
        }
        return null;
    }

    public static Elemento getInicio() {
        return inicio;
    }

    public static void setInicio(Elemento inicio) {
        Lista.inicio = inicio;
    }

    public static Elemento getAtual() {
        return atual;
    }

    public static void setAtual(Elemento atual) {
        Lista.atual = atual;
    }

    public static Elemento getAux() {
        return aux;
    }

    public static void setAux(Elemento aux) {
        Lista.aux = aux;
    }
}
