/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ado2Fila;

/**
 *
 * @author eric
 */
public class BancoSenac {

    private String nome, motivo;
    private int senha, idade;
    private static int num = 500;

    public BancoSenac(String nome, int idade, String motivo) {
        this.nome = nome;
        this.idade = idade;
        this.motivo = motivo;
        this.senha = num++;
    }

    public BancoSenac() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int id) {
        this.senha = id;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    @Override
    public String toString() {
        return "Senha: " + senha + ", Nome: " + nome.trim() + ", idade: " + idade + ", motivo: " + motivo;
    }

}
