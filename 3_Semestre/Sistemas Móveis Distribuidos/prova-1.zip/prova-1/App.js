import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  Alert,
  Button,
} from 'react-native';
import Constants from 'expo-constants';

import AssetExample from './components/AssetExample';
import {Card} from 'react-native-paper';

//com arrow function
export default function App() {
  
  const [jsonData, setCachorro] = useState(null);
  const dogzin = ()=> {
    const endpoint = 'https://dog.ceo/api/breeds/image/random';

    fetch(endpoint).then((resposta) => resposta.json()).then((json) => {
        console.log(json);
        const cachorro = {
          imagem: json.message,
          status: json.status
        };
        setCachorro(cachorro);
      })
      .catch(() => {Alert.alert('Auau não disponivel');});
  }

  return (
    <View style={styles.container}>
      {jsonData != null && (
        <View style={styles.container2}>
          <Image
            source={{ uri: jsonData.imagem }}
            style={styles.tinyLogo}
          />
          <Text style={styles.paragraph}>Au Au</Text>
        </View>
      )}
      <View style={styles.buttonStyle}>
        <Button 
        onPress={()=>dogzin()}
        title= 'Pressione Aqui'
        color= '#D2691E'
        style={styles.buttonStyle}
        />
      </View>
  </View>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#86a8b0',
    padding: 8,
  },
  container2: {
    flex: 3,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    padding: 1,
  },
  paragraph: {
    fontFamily: 'Segoe Script',
    margin: 15,
    padding: 10,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: '#7B68EE',
  },
  tinyLogo: {
    width: 300,
    height: 300,
    alignSelf: 'center',
  },
  buttonStyle: {
        margin: 50,
        marginTop: 10,
  }
});
