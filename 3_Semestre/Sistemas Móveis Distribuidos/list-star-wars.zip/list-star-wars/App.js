import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  Pressable,
  Image,
  Alert,
} from 'react-native';
import Constants from 'expo-constants';

const DATA = [
  {
    id: 2,
    avatar: 'https://findicons.com/files/icons/512/star_wars/128/r2_d2.png',
    name: 'R2-D2',
    height: '96',
    mass: '32',
    hair_color: 'n/a',
    skin_color: 'white, blue',
    eye_color: 'red',
    birth_year: '33BBY',
    gender: 'n/a',
    homeworld: 'Planeta Natal: Naboo',
  },
  {
    id: 3,
    avatar:'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Luke-Skywalker-01-icon.png',
    name: 'Luke Skywalker',
    height: '172',
    mass: '77',
    hair_color: 'blond',
    skin_color: 'fair',
    eye_color: 'blue',
    birth_year: '19BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Tatooine',
  },
  {
    id: 1,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/C3PO-icon.png',
    name: 'C-3PO',
    height: '167',
    mass: '75',
    hair_color: 'n/a',
    skin_color: 'gold',
    eye_color: 'yellow',
    birth_year: '112BBY',
    gender: 'n/a',
    homeworld: 'Planeta Natal: Tatooine',
  },
  {
    id: 4,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Vader-02-icon.png',
    name: 'Darth Vader',
    height: '202',
    mass: '136',
    hair_color: 'none',
    skin_color: 'white',
    eye_color: 'yellow',
    birth_year: '41.9BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Tatooine',
  },
  {
    id: 5,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Leia-icon.png',
    name: 'Leia Organa',
    height: '150',
    mass: '49',
    hair_color: 'brown',
    skin_color: 'light',
    eye_color: 'brown',
    birth_year: '19BBY',
    gender: 'female',
    homeworld: 'Planeta Natal: Alderaan',
  },
  {
    id: 8,
    avatar: 'https://static.wikia.nocookie.net/starwars/images/c/cb/R5-D4_Sideshow.png/revision/latest/top-crop/width/360/height/360?cb=20160809033145',
    name: 'R5-D4',
    height: '97',
    mass: '32',
    hair_color: 'n/a',
    skin_color: 'white, red',
    eye_color: 'red',
    birth_year: 'unknown',
    gender: 'n/a',
    homeworld: 'Planeta Natal: Tatooine',
  },
  {
    id: 10,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Master-Obi-Wan-icon.png',
    name: 'Obi-Wan Kenobi',
    height: '182',
    mass: '77',
    hair_color: 'auburn, white',
    skin_color: 'fair',
    eye_color: 'blue-gray',
    birth_year: '57BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Stewjon',
  },
  {
    id: 11,
    avatar: 'https://w7.pngwing.com/pngs/346/614/png-transparent-anakin-skywalker-luke-skywalker-star-wars-episode-iii-revenge-of-the-sith-count-dooku-hayden-christensen-others-chewbacca-academic-dress-mace-windu.png',
    name: 'Anakin Skywalker',
    height: '188',
    mass: '84',
    hair_color: 'blond',
    skin_color: 'fair',
    eye_color: 'blue',
    birth_year: '41.9BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Tatooine',
  },
  {
    id: 12,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Tarkin-icon.png',
    name: 'Wilhuff Tarkin',
    height: '180',
    mass: 'unknown',
    hair_color: 'auburn, grey',
    skin_color: 'fair',
    eye_color: 'blue',
    birth_year: '64BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Eriadu',
  },
  {
    id: 13,
    avatar: 'https://www.pngarts.com/files/7/Star-Wars-Chewbacca-Transparent-Background-PNG.png',
    name: 'Chewbacca',
    height: '228',
    mass: '112',
    hair_color: 'brown',
    skin_color: 'unknown',
    eye_color: 'blue',
    birth_year: '200BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Kashyyyk',
  },
  {
    id: 14,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Han-Solo-02-icon.png',
    name: 'Han Solo',
    height: '180',
    mass: '80',
    hair_color: 'brown',
    skin_color: 'fair',
    eye_color: 'brown',
    birth_year: '29BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Corellia',
  },
  {
    id: 15,
    avatar: 'https://icons.iconarchive.com/icons/jonathan-rey/star-wars-characters/256/Greedo-icon.png',
    name: 'Greedo',
    height: '173',
    mass: '74',
    hair_color: 'n/a',
    skin_color: 'green',
    eye_color: 'black',
    birth_year: '44BBY',
    gender: 'male',
    homeworld: 'Planeta Natal: Rodia',
  },
  {
    id: 16,
    avatar: 'https://aux.iconspalace.com/uploads/17942072461815112611.png',
    name: 'Jabba Desilijic Tiure',
    height: '175',
    mass: '1,358',
    hair_color: 'n/a',
    skin_color: 'green-tan, brown',
    eye_color: 'orange',
    birth_year: '600BBY',
    gender: 'hermaphrodite',
    homeworld: 'Planeta Natal: Nal Hutta',
  },
];

//com arrow function
const Pessoa = ({ nome, minhaFunc, link }) => (
  <View>
    <Pressable onPress={minhaFunc}>
      <Image
        style={styles.tinyLogo}
        source={{
          uri: link,
        }}
      />

      <Text style={styles.paragraph}>{nome}</Text>
    </Pressable>
  </View>
);

export default function App() {
  function renderItem({ item }) {
    let nomeCompleto = item.name;

    return (
      <Pessoa
        nome={nomeCompleto}
        minhaFunc={() => Alert.alert(item.homeworld)}
        link={item.avatar}
      />
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#86a8b0',
    padding: 8,
  },
  paragraph: {
    margin: 12,
    padding: 10,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    backgroundColor: 'yellow',
  },
  tinyLogo: {
    width: 50,
    height: 50,
    alignSelf: 'center',
  },
});
